from playsound import playsound
playsound('/Users/muhammed/Downloads˜')