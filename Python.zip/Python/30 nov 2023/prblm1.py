# Aim- To Demonstrate 8 types of operators with examples
# 1 Arithmetic ✔️
'''a=float(input('enter first value: '))
b=float(input('enter second value: '))
# print(a,b)
cdn=(input('enter the operator to perform '))
if cdn=="+":
    print(a, " + ",b," = ",a+b)
elif cdn=="-":
    print(a, " - ",b," = ",a-b)
elif cdn=="*":
    print(a, " x ",b," = ",a*b)
elif cdn=="/":
    print(a, " ÷ ",b," = ",a/b)
elif cdn=="^":
    print(a, " ^ ",b," = ",a**b)
elif cdn=="%":
    print(a, " % ",b," = ",a%b)
elif cdn=="//":
    print(a, " // ",b," = ",a//b) 
else:
    print("invalid operation")'''

# Relational ✔️
"""a=float(input("enter first number"))
b=float(input("enter second number"))
c=float(input("enter third number"))
if a>b:
    if c<a:
        print(a," greater than",b," & ",c )
    else:
        print(c," greater than",a," & ",b )
else:
    if b>c:
        print(b," greater than",a," & ",c )
    else:
        print(c," greater than",a," & ",b )

a=6
b=4
if a==b:print("both a and b are equal")
else:print(a," not equal to ",b)

a=6
b=4
if a>=b:print(a," greater than or equal to ",b)
else:print(a," less than equal to ",b)"""

# Logical ✔️
"""a=8
b=6
c=6
print( a>b and a>c)

print( a>b or a<c)

print(not( a>b and a>c))"""

# bitwise
"""
"""

# membership
"""
"""

# Assignment
"""
"""

# Ternary
'''
'''

# Identity

x = ["apple", "banana"]
y = ["apple", "banana"]
z = x

print(x is z)

print(x is y)

print(x == y) # to identify the difference between "is" and "=="

