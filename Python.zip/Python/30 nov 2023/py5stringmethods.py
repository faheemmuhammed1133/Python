# substring methods˳
s='012345'
print(s[3])
print(s[1:4])
print(s[2:])
print(s[:4])
print(s[-1])
print(s[::1+1])
print(s[1::2])
print(len(s))