# dictionary cretion and modification
x={1:'zero',"to":1,'1':[3,7,8]}
# print(x[1])
# print(x['to'])
# print(x['1'])

# x['1']=56
x[4]='test'
del(x['to'])
print(x)