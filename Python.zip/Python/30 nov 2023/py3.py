# operator overloading +, concatenating
x='hello'
x=x + 'friend'
print (x)