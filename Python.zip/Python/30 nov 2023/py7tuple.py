# tuple 
x=(2,)
print(x)

x=(1,2,3)
print(x[1:])
