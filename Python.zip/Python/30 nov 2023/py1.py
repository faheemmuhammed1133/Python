# arithmetic operations

a=2
b=4
print(a, " + ",b," = ",a+b)
print(a//b)
print(a**b)