# print('Hello World!')
# print("Hello World!")
fname = 'Welcome'
lname ="Btech"
print(fname,lname)