# average of three numbers 
a=int(input("enter your value"))
print(a)
b=5
c=6
print((a+b+c)/3)