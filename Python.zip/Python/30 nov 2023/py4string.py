# """"""
print("""British logistics supported the Anglo-Canadian forces in the Western Allied invasion of Germany,
the final campaign of the Second World War in Europe.er. \"The First Canadian Army was reunited by the return of divisions\"
from Italy. The army roadheads were mainly supplied by rail; fuel was brought by tankers and the Operation Pluto pipeline.
illions of rounds of ammunition were used in Operation Veritable, the advance to the Rhine; and Operation Plunder, the Rhine crossing,
which also featured an airborne operation. Engineers soon had bridges in operation. During April 1945""")