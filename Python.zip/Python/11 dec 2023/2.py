# 1,Wap to create a dictionary with mixed keys, and 
#      i print the keys, 
#     ii print values &
#     iii key-value pairs
'''dict= {1 : "India", 'city' : 'New Delhi', 'Record' : {'id' : 101, 'name' : 'Amit', 'age': 21}}
for i in dict:
    print(i)
print("")
for i in dict:
    print(dict[i])
print("")
for i in dict:
    print(i,":-",dict[i])'''

# 2,Wap for accessing elements from a dictionary.     i/p: r1={'id':101,'name':'Amit','Age':21}
#   a. By using key name.
#   b. By using get() method.
'''r1={'id':101,'name':'Amit','Age':21}
print(r1['Age'])
print(r1.get("name"))'''

# 