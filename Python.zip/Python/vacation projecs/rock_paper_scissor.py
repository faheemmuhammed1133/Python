# 3 -1 rock paper scissor
rps={1:"rock",2:"paper",3:"scissor"}
from time import sleep
from random import randint 
cpoints=0
upoints=0
gccount=0
def counter(cadd,uadd,gc):
    global cpoints,upoints,gccount
    cpoints+=cadd
    upoints+=uadd
    gccount+=gc

def results(nm):
    print("Total match played :",gccount)
    print("Computer Points    :",cpoints)
    print(nm," points     :",upoints)
    print()
    if cpoints>upoints:
        print("computer won the match by",cpoints-upoints)
    elif upoints>cpoints:
        print(nm," won the match by",upoints-cpoints)
    else:
        print("the match is a draw !")

def agn(nm):
    print("do you want to play again(y/n)",nm)
    n=input().upper()
    if n=='Y':
        play(nm)
    elif n=="N":
        print("thank you for playing ! ")
        results(nm)
        exit()
    else:
        print("!! ERROR !!\n")
        agn(nm)
        
def rand():
    return randint(1,3)

def usch():
    while True:
        print("enter you choice",rps,"\nenter (1-3) only ")
        userchoice=int(input(""))
        if userchoice <=3 and userchoice >= 1:
            return userchoice
            
        
    

def checkwinner(cc,uc,nm):
    if cc==uc:
        print("game tie !\n ")
        counter(0,0,1)
        agn(nm)
    elif (cc==1 and uc==3) or (cc==2 and uc==1) or (cc==3 and uc==2):
        print("computer wins ! \nBetter luck next time\n")
        counter(1,0,1)
        agn(nm)
    else:
        print("Congratulations , You won",nm,"\n")
        counter(0,1,1)
        agn(nm)

def play(nm):
    cc=rand()
    comp_option=rps[cc]

    uc=usch()
    user_option=rps[uc]
    print(nm,"u hv choosen",user_option)
    print("comp hv chosen ",comp_option)

    sleep(.5)
    checkwinner(cc,uc,nm)

print("********welcome*********")
name=input("enter your name ")
print("hello,",name)
play(name)
    