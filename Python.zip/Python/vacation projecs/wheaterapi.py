# weather api
import requests

api_key="c27bb81cd8a672d9cc9b1b039295732c"
base_Url="http://api.openweathermap.org/data/2.5/weather"

city=input("enter city name ")

url=f"{base_Url}?appid={api_key}&q={city}"
response=requests.get(url)
if response.status_code==200:
    data=response.json()
    print("Weather :",data['weather'][0]['description'])
    print("Temprature :",round(data['main']['temp']-273.15,2))

else:
    print("Error request !")