# wap to find the sum of first 2000 odd num
s=0
for i in range(1,4000,2):
    s+=i
print ("sum of first 2000 odd num is",s)