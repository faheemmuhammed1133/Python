d=int(input("enter your Day of birth "))
m=int(input("enter your Month of birth "))
y=int(input("enter your Year of birth "))
for i in range(2,y-1,-1):
    
    # for j in range(12):
    print(i)