# simple if statement
"""num=4
if num>0:
    print(num,"is positive.")
    print("testing")
print("this is always printed")"""

# if .. else
# WAP to find the input number is wheather even or odd
"""
n=int(input("enter a number to check wheather even or odd: "))
if n%2==0:
    print(n,"is even")
else:
    print(n,"is odd")    
"""

# else if ladder
# WAP to display grade of student base on marks entered
"""
mark=float(input("enter your mark "))
if mark>=70:
    print("Distinction")
elif mark>=60:
    print("first class")
elif mark>=50:
    print("second class")
else :
    print("passed")
"""
# 
