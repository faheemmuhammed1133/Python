# 3 area and perimeter of rectangle
l=float(input("enter length "))
b=float(input("enter breadth "))

print("area of rectangle =", l*b)

print("perimeter of rectangle =", 2*(l+b))