# 9 multiplication table of given number
x=int(input("enter the number to get multiplication table "))
r=int(input("enter the range to get multiplication table "))
for i in range(x,r*x+1,x):
  print(i)