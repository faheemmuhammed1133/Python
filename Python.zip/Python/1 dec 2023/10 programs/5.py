# 5 odd or even
a=float(input("enter num 1 "))
if a%2==0:
  print(a,"is even")
else:
  print(a,"is even")