# 4 simple interest
p=float(input("enter principle "))
t=float(input("enter time "))
r=float(input("enter rate of interest "))
print("simple interest =",p*r*t/100)