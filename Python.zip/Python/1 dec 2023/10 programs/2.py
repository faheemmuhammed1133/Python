# 2 area of a circle
r=float(input('enter the radius of circle '))
print("area of circle with radius",r,"=",(22/7)*r*r)