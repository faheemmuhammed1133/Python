# 1 program to take two input and find sum
a=float(input("enter num 1 "))
b=float(input("enter num 2 "))
print("sum of",a ,",",b," = ",a+b)