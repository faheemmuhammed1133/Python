# demonstration of tuple

t=(1,2,4,2,4,3,2,6,2)
'''print(t.count(4))
# print(t)
# loop through tuple
for i in t:
    print(t)'''

# with if 
'''if 1 in t:
    print("yes")
else:
    print("no")'''
# length
'''print(len(t))'''
# add item?
'''t[5]="a" # 'tuple' object does not support item assignment
print(t)'''

# append or concatenate
'''l.append(2)

t+=(2,4)
print(t)'''

# .count
print(t.index(2))