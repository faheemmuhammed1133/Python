# creation of list tuple dictionary
l=[2,5,7,"+"]
print(l[2])
print(l)

# tuple
x=(1,2,3)
print(x[1:])
print(x)

# dictionary
x={1:'zero',"to":1,'1':[3,7,8],"k":{"l":"g",1:6}}
print(x)
print(x[1])