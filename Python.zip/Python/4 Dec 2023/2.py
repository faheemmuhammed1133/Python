x=(1,2,3)
print(x[1:])
y=(2,)
print(y)