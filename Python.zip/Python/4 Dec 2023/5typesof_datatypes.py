# types of datatypes.
x=1
k=[1,2]
j=(1,2)
d={1:3}
y="list"
n=4.7
print(type(x))
print(type(k))
print(type(j))
print(type(d))
print(type(y))
print(type(n))